import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'image-div-poc';
  boxes: any[] = [1, 2, 3, 4, 5, 6];
  images: any[] = [{ id: 1, path: '../assets/image1.jpg', show: false },
  { id: 2, path: '../assets/image2.jpg', show: false }
    , { id: 3, path: '../assets/image3.jpg', show: false }
    , { id: 4, path: '../assets/image4.jpg', show: false }
    , { id: 5, path: '../assets/image5.jpg', show: false }
    , { id: 6, path: '../assets/image6.jpg', show: false }];


  enableBox(index: any) {
    for (let i = 0; i < this.images.length; i++) {
      if (i < index && this.images[i] && !this.images[i].show) {
        this.images[i].show = true;
      }
    }
    this.images[index].show = true;
  }
  deleteImage(index :any) {
    this.images.splice(index, 1);
  }
}

